<?php echo $__env->make('sidebar.menu_kepala_gudang', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<h1>
  Riwayat Sparepart
</h1>

<div class="card shadow">
  <div class="card-body">
    <div class="table-responsive">
      <table class="table " id="dataRiwayatSparepart" width="100%" cellspacing="0">
        <thead>
          <tr>
            <th>No</th>
            <th>Kode Sparepart</th>
            <th>Nama Sparepart</th>
            <th>Total Digunakan</th>
            <th>Stock</th>
            <th>
              Detail
            </th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sparepart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($sparepart->kode_sparepart); ?></td>
            <td><?php echo e($sparepart->nama_sparepart); ?></td>
            <td><?php echo e($sparepart->total_used); ?></td>
            <td><?php echo e($sparepart->stock); ?></td>
            <td>
              <a href="riwayat/<?php echo e($sparepart->id); ?>">
                Detail
              </a>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
$(document).ready(function() {
  $('#dataRiwayatSparepart').DataTable({
    autoWidth: true,
    "lengthMenu": [
      [10, 25, 50, -1],
      [10, 25, 50, "All"]
    ]
  });
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WORK\SI-Reminder-Management-Armada-PO-Haryanto\resources\views/kepala_gudang/riwayat-sparepart.blade.php ENDPATH**/ ?>