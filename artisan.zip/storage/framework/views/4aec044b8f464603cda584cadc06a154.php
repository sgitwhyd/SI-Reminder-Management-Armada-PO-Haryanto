<?php echo $__env->make('sidebar.menu_crew', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-12 mt-5">
    <h1>
      Riwayat Perawatan
    </h1>
    <div class="card shadow">
      <div class="card-body">
        <table class="table" id="dataPerawatan">
          <thead>
            <tr>
              <th>
                Tanggal
              </th>
              <th>
                Oli Gardan
              </th>
              <th>
                Oli Transmisi
              </th>
              <th>
                Oli Mesin
              </th>
              <th>
                Tanda Tangan Kepala Gudang
              </th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td>
                <?php echo e($item->tanggal); ?>

              </td>
              <td><?php echo e($item->oli_gardan); ?> </td>
              <td><?php echo e($item->oli_mesin); ?> </td>
              <td><?php echo e($item->oli_transmisi); ?> </td>
              <td>
                <img src="<?php echo e(asset('storage/' . $item->ttd_kepala_gudang)); ?>" alt="ttd_kepala_gudang" width="100">
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
$('#dataPerawatan').DataTable({
  autoWidth: true,
  "lengthMenu": [
    [10, 25, 50, -1],
    [10, 25, 50, "All"]
  ]
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WORK\SI-Reminder-Management-Armada-PO-Haryanto\resources\views/crew/riwayat-perawatan.blade.php ENDPATH**/ ?>