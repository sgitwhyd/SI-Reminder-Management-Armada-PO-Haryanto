
<?php echo $__env->make('sidebar.menu_crew', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-12 mt-5">
    <h1>
      Riwayat Perbaikan
    </h1>
    <div class="card shadow">
      <div class="card-body">
        <table class="table" id="dataPerbaikan">
          <thead>
            <tr>
              <th>
                Tanggal
              </th>
              <th>
                Nama Sparepart
              </th>
              <th>
                Part No,
              </th>
              <th>
                Jumlah
              </th>
              <th>
                Nominal
              </th>
              <th>
                Keterangan
              </th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td>
                <?php echo e($item->created_at); ?>

              </td>
              <td>
                <?php $__currentLoopData = $item->spareparts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sparepart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($sparepart->nama_sparepart); ?>, <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </td>
              <td>
                <?php $__currentLoopData = $item->spareparts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sparepart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($sparepart->kode_sparepart); ?>, <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </td>
              <td>
                <?php echo e($item->spareparts->count()); ?>

              </td>
              <td>
                <?php echo e($item->biaya); ?>

              </td>
              <td>
                <?php echo e($item->keterangan); ?>

              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
$('#dataPerbaikan').DataTable({
  autoWidth: true,
  "lengthMenu": [
    [10, 25, 50, -1],
    [10, 25, 50, "All"]
  ]
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WORK\SI-Reminder-Management-Armada-PO-Haryanto\resources\views/crew/riwayat-perbaikan.blade.php ENDPATH**/ ?>