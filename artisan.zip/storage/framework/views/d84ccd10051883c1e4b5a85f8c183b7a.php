<?php echo $__env->make('sidebar.menu_kepala_gudang', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<h2 class="mb-2 page-title">Data Perawatan</h2>
<p class="card-text">Mencakup data perawatan tiap - tiap bus</p>

<a href="/kepala-gudang/perawatan/buat-perawatan" class="btn btn-primary mb-3">
  + Tambah Data Perawatan
</a>

<div class="card shadow">
  <div class="card-body">
    <table class="table datatables" id="dataPerawatan">
      <thead>
        <tr>
          <th>
            No
          </th>
          <th>
            Armada/No. Lambung
          </th>
          <th>
            Tanggal Periksa
          </th>
          <th>
            Oli Gardan
          </th>
          <th>
            Oli Transmisi
          </th>
          <th>
            Oli Mesin
          </th>
          <th>
            Tertanda
          </th>
          <th>
            Action
          </th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($index + 1); ?></td>
          <td><?php echo e($value->armada->no_lambung); ?></td>
          <td><?php echo e($value->tanggal); ?></td>
          <td><?php echo e($value->oli_gardan); ?> </td>
          <td><?php echo e($value->oli_transmisi); ?> </td>
          <td><?php echo e($value->oli_mesin); ?> </td>
          <td>
            <img src="<?php echo e(asset('storage/' . $value->ttd_kepala_gudang)); ?>" style="width: 120px;" alt="tanda-tangan">
          </td>
          <td>
            <button class="btn btn-sm dropdown-toggle more-horizontal" type="button" data-toggle="dropdown"
              aria-haspopup="true" aria-expanded="false"></button>
            <div class="dropdown-menu dropdown-menu-right">
              <a href="/kepala-gudang/perawatan/edit-perawatan/<?php echo e($value->id); ?>" class="dropdown-item edit-perawatan">Edit</a>
              <button type="button" class="dropdown-item delete-perawatan" data-id="<?php echo e($value->id); ?>">Delete</button>
            </div>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
$('#dataPerawatan').DataTable({
  autoWidth: true,
  "lengthMenu": [
    [10, 25, 50, -1],
    [10, 25, 50, "All"]
  ]
});

$(document).ready(function() {
  // Delete post
  $(document).on('click', '.delete-perawatan', function() {
    var postId = $(this).data('id');
    if (confirm('Apakah anda yakin untuk menghapus perawatan?')) {
      $.ajax({
        url: 'perawatan/delete/' + postId,
        type: 'DELETE',
        data: {
          _token: '<?php echo e(csrf_token()); ?>'
        },
        success: function(data) {
          location.reload();
        },
        error: function(xhr, status, error) {
          console.error('Error:', error);
        }
      });
    }
  });

})
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WORK\SI-Reminder-Management-Armada-PO-Haryanto\resources\views/kepala_gudang/perawatan.blade.php ENDPATH**/ ?>