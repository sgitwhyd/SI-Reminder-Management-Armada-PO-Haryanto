<?php echo $__env->make('sidebar.menu_kepala_gudang', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<h1>
  Detail Perbaikan
</h1>


<div class="card shadow">
  <div class="card-body">
    <div class="col-12">
      <h5>
        Detail Armada
      </h5>

      <table class="table">
        <tr>
          <td>
            No. Lambung
          </td>
          <td>
            <?php echo e($data->armada->no_lambung); ?>

          </td>
        </tr>
        <tr>
          <td>
            No. Polisi
          </td>
          <td>
            <?php echo e($data->armada->no_polisi); ?>

          </td>
        </tr>
        <tr>
          <td>
            Tahun
          </td>
          <td>
            <?php echo e($data->armada->tahun); ?>

          </td>
        </tr>
        <tr>
          <td>
            No. STNK
          </td>
          <td>
            <?php echo e($data->armada->no_stnk); ?>

          </td>
        </tr>
        <tr>
          <td>
            Jenis Trayek
          </td>
          <td>
            <?php echo e($data->armada->jenis_trayek); ?>

          </td>
        </tr>
        <tr>
          <td>
            Trayek
          </td>
          <td>
            <?php echo e($data->armada->trayek); ?>

          </td>
        </tr>
      </table>
    </div>
    <div class="col-12">
      <h5>
        Daftar Sparepart Yang Digunakan
      </h5>
      <table class="table datatables" id="dataPerbaikan">
        <thead>
          <tr>
            <th>#</th>
            <th>
              Nama Sparepart
            </th>
            <th>
              Harga Satuan
            </th>
            <th>
              Jumlah
            </th>
            <th>
              Total Harga
            </th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $data->sparepart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td>
              <?php echo e($loop->iteration); ?>

            </td>
            <td><?php echo e($value->detail->nama_sparepart); ?></td>
            <td>
              Rp. <?php echo e(number_format($value->detail->harga, 0,0)); ?>

            </td>
            <td><?php echo e($value->jumlah); ?></td>
            <td>Rp. <?php echo e(number_format($value->detail->harga * 
              $value->jumlah, 0,0)); ?></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td colspan="4">
              <b>Total Biaya</b>
            </td>
            <td>
              <b>Rp. <?php echo e(number_format($data->biaya, 0,0)); ?></b>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <div class="col-12">
      <h5>
        Keterangan
      </h5>
      <p>
        <?php echo e($data->keterangan); ?>

      </p>
      <a href="pdf/<?php echo e(request('id')); ?>" target="_blank" class="btn btn-primary">
        Cetak Data Perbaikan
      </a>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WORK\SI-Reminder-Management-Armada-PO-Haryanto\resources\views/kepala_gudang/detail-perbaikan.blade.php ENDPATH**/ ?>