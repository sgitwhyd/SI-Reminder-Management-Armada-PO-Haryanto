<?php echo $__env->make('sidebar.menu_kepala_gudang', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<h2 class="mb-2 page-title">Data Perbaikan</h2>
<p class="card-text">Mencakup data perbaikan tiap - tiap bus</p>

<a href="/kepala-gudang/perbaikan/buat-perbaikan" class="btn btn-primary mb-3">
  + Tambah Data Perbaikan
</a>

<div class="card shadow">
  <div class="card-body">
    <table class="table datatables" id="dataPerbaikan">
      <thead>
        <tr>
          <th>#</th>
          <th>Armada/No. Lambung</th>
          <th>Tanggal Perbaikan</th>
          <th>Suku Cadang</th>
          <th>Biaya</th>
          <th>Keterangan</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($index + 1); ?></td>
          <td><?php echo e($value->armada->no_lambung); ?></td>
          <td><?php echo e($value->tanggal); ?></td>
          <td>
            <?php if($value->spareparts->isEmpty()): ?>
            -
            <?php else: ?>
            <?php $__currentLoopData = $value->spareparts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sparepart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($sparepart->nama_sparepart); ?>, <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
          </td>
          <td>Rp. <?php echo e(number_format($value->biaya, 0,0)); ?></td>
          <td><?php echo e($value->keterangan); ?></td>
          <td>
            <button class="btn btn-sm dropdown-toggle more-horizontal" type="button" data-toggle="dropdown"
              aria-haspopup="true" aria-expanded="false"></button>
            <div class="dropdown-menu dropdown-menu-right">
              <a href="/kepala-gudang/perbaikan/detail/<?php echo e($value->id); ?>" class="dropdown-item delete-rampcheck">Detail</a>
              <button type=" button" class="dropdown-item delete-perbaikan" data-id="<?php echo e($value->id); ?>">Delete</button>
            </div>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
$('#dataPerbaikan').DataTable({
  autoWidth: true,
  "lengthMenu": [
    [10, 25, 50, -1],
    [10, 25, 50, "All"]
  ]
});

$(document).ready(function(){
  // Delete post
    $(document).on('click', '.delete-perbaikan', function() {
        var postId = $(this).data('id');
        if (confirm('Apakah anda yakin untuk menghapus perbaikan?')) {
          $.ajax({
              url: 'perbaikan/delete/' + postId,
              type: 'DELETE',
              data: {
                _token: '<?php echo e(csrf_token()); ?>'
              },
              success: function(data) {
                location.reload();
              },
              error: function(xhr, status, error) {
                console.error('Error:', error);
              }
          });
        }
    });

  })

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WORK\SI-Reminder-Management-Armada-PO-Haryanto\resources\views/kepala_gudang/perbaikan.blade.php ENDPATH**/ ?>