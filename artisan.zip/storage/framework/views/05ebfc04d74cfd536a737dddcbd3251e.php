<?php echo $__env->make('sidebar.menu_crew', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-12">
    <?php if($alertPerawatan): ?>
    <div class="alert alert-warning" role="alert">
      <span class="fe fe-alert-triangle fe-16 mr-2"></span> Waktunya Melakukan Perawatan Berkala, Segera Lakukan
      Perawatan, Terakhir dilakukan pada <?php echo e($alertPerawatan->tanggal); ?>

    </div>
    <?php endif; ?>
    <?php if($dataBus): ?>
    <div class="row">
      <div class="col-md-6 col-xl-3 mb-4">
        <div class="card shadow border-0">
          <div class="card-body">
            <div class="row align-items-center">
              <div class="col-3 text-center">
                <span class="circle circle-sm bg-primary">
                  <i class="fe fe-16 fe-shopping-cart text-white mb-0"></i>
                </span>
              </div>

              <div class="col pr-0">
                <p class="small text-muted mb-0">Nomor Lambung</p>
                <span class="h3 mb-0">
                  <?php echo e($dataBus->no_lambung); ?>

                </span>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div> <!-- end section -->
    <?php else: ?>
    <div class="alert alert-warning" role="alert">
      <span class="fe fe-alert-triangle fe-16 mr-2"></span> Anda Belum Terdaftar Pada Armada Manapun
    </div>
    <?php endif; ?>
  </div>
  <?php if($dataBus): ?>
  <div class="col-12">
    <h1>
      Detail Armada
    </h1>
    <div class="row">
      <div class="col-md-6 col-sm-12">
        <div class="d-flex flex-column mb-3">
          <strong>Nomor Lambung</strong>
          <span>
            <?php echo e($dataBus->no_lambung); ?>

          </span>
        </div>
        <div class="d-flex flex-column mb-3">
          <strong>Nomor Polisi</strong>
          <span>
            <?php echo e($dataBus->no_polisi); ?>

          </span>
        </div>
        <div class="d-flex flex-column mb-3">
          <strong>
            Trayek
          </strong>
          <span>
            <?php echo e($dataBus->trayek); ?>

          </span>
        </div>
        <div class="d-flex flex-column mb-3">
          <strong>
            Crew
          </strong>
          <span>
            <?php $__currentLoopData = $dataBus->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($user->full_name); ?>,
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </span>
        </div>
      </div>
      <div class="col-md-6 col-sm-12">
        <div class="d-flex flex-column mb-3">
          <strong>
            Foto Armada
          </strong>
          <img src="<?php echo e(asset('storage/' . $dataBus->gambar_armada)); ?>" alt="Foto Armada" width="200">
        </div>
      </div>
    </div>
  </div>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WORK\SI-Reminder-Management-Armada-PO-Haryanto\resources\views/crew/dashboard.blade.php ENDPATH**/ ?>