<?php echo $__env->make('sidebar.menu_kepala_gudang', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
  <div class="col-12">
    <?php if($alertPerawatan != null): ?>
    <?php $__currentLoopData = $alertPerawatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="alert alert-warning" role="alert">
      <span class="fe fe-alert-triangle fe-16 mr-2"></span>Bus <span style="font-weight: 700;">
        <?php echo e($item->armada->no_lambung); ?>

      </span>, Waktunya Melakukan
      Perawatan
      Berkala, Segera Lakukan
      Perawatan, Terakhir dilakukan pada <span style="font-weight: 700;">
        <?php echo e($item->tanggal); ?>

      </span>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
    <div class="alert alert-success" role="alert">
      <span class="fe fe-check-circle fe-16 mr-2"></span>Semua Bus Sedang Dalam
      Kondisi Baik
    </div>
    <?php endif; ?>
  </div>
</div> <!-- .row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WORK\SI-Reminder-Management-Armada-PO-Haryanto\resources\views/kepala_gudang/dashboard.blade.php ENDPATH**/ ?>