<?php echo $__env->make('sidebar.menu_kepala_gudang', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-12">
  <h2 class="mb-2 page-title">Detail Riwayat Penggunaan <?php echo e($sparepart->nama_sparepart); ?></h2>
  <div class="card shadow">
    <div class="card-body">
      <table class="table">
        <tr>
          <th>
            Armada
          </th>
          <th>
            Tanggal
          </th>
        </tr>
        <?php $__currentLoopData = $spareparts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sparepart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($sparepart->no_lambung); ?></td>
          <td><?php echo e($sparepart->tanggal); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </table>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WORK\SI-Reminder-Management-Armada-PO-Haryanto\resources\views/kepala_gudang/detail-riwayat-sparepart.blade.php ENDPATH**/ ?>