<?php echo $__env->make('sidebar.menu_kepala_gudang', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
  <div class="col-12">
    <h2 class="mb-2 page-title">Data Rampcheck</h2>
    <p class="card-text">Mencakup data pengecekan sebelum keberangkatan</p>
    <a href="<?php echo e('rampcheck/add'); ?>" class="btn mb-2 btn-primary"><i class="fe fe-plus"></i> Tambah</a>
    <div id="form-notif">
      <?php if(session('success')): ?>
      <div class="alert alert-success">
        <p><?php echo e(session('success')); ?></p>
      </div>
      <?php endif; ?>
    </div>
    <div class="row my-4">
      <div class="col-md-12">
        <div class="card shadow">
          <div class="card-body">
            <table class="table datatables" id="dataRampcheck">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Tgl Periksa</th>
                  <th>Petugas</th>
                  <th>No Lambung</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $list_rampcheck; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td>
                    <?php echo e($key + 1); ?>

                  </td>
                  <td>
                    <?php echo e($value->tgl_rampcheck); ?>

                  </td>
                  <td>
                    <?php echo e($value->user->full_name); ?>

                  </td>
                  <td>
                    <?php echo e($value->no_lambung); ?>

                  </td>
                  <td>
                    <?php if($value->status == 'PENDING'): ?>
                    <span class="badge badge-warning">
                      PENDING
                    </span>
                    <?php elseif($value->status == 'APPROVE'): ?>
                    <span class="badge badge-success">
                      APPROVE
                    </span>
                    <?php else: ?>
                    <span class="badge badge-danger">
                      REJECT
                    </span>
                    <?php endif; ?>
                  </td>
                  <td>
                    <button class="btn btn-sm dropdown-toggle more-horizontal" type="button" data-toggle="dropdown"
                      aria-haspopup="true" aria-expanded="false"></button>
                    <div class="dropdown-menu dropdown-menu-right">
                      <a href="<?php echo e('rampcheck/pdf/'.$value['id_rampcheck']); ?>" class="dropdown-item">View</a>
                      <a href="<?php echo e('rampcheck/edit/'.$value['id_rampcheck']); ?>" class="dropdown-item">Konfirmasi</a>
                      <button type="button" class="dropdown-item delete-rampcheck"
                        data-id="<?php echo e($value['id_rampcheck']); ?>">Delete</button>
                    </div>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
$('#dataRampcheck').DataTable({
  autoWidth: true,
  "lengthMenu": [
    [10, 25, 50, -1],
    [10, 25, 50, "All"],
  ]
});

$(document).ready(function() {
  // Delete post
  $(document).on('click', '.delete-rampcheck', function() {
    var postId = $(this).data('id');
    if (confirm('Apakah anda yakin untuk menghapus rampcheck?')) {
      $.ajax({
        url: 'rampcheck/delete/' + postId,
        type: 'DELETE',
        data: {
          _token: '<?php echo e(csrf_token()); ?>'
        },
        success: function(data) {
          location.reload();
        },
        error: function(xhr, status, error) {
          console.error('Error:', error);
        }
      });
    }
  });

})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WORK\SI-Reminder-Management-Armada-PO-Haryanto\resources\views/kepala_gudang/rampcheck.blade.php ENDPATH**/ ?>