
<?php echo $__env->make('sidebar.menu_mekanik', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<h2 class="mb-2 page-title">Data Perbaikan</h2>
<p class="card-text">Mencakup data perbaikan tiap-tiap armada</p>
<div class="card shadow">
  <div class="card-body">
    <table class="table datatables" id="dataPerbaikan">
      <thead>
        <tr>
          <th>#</th>
          <th>
            Armada/No. Lambung
          </th>
          <th>
            Tanggal Perbaikan
          </th>
          <th>
            Suku Cadang
          </th>
          <th>
            Biaya
          </th>
          <th>
            Keterangan
          </th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($index + 1); ?></td>
          <td><?php echo e($value->armada->no_lambung); ?></td>
          <td>
            <?php echo e($value->tanggal); ?>

          </td>
          <td>
            <?php if($value->spareparts->isEmpty()): ?>
            -
            <?php else: ?>
            <?php $__currentLoopData = $value->spareparts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sparepart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($sparepart->nama_sparepart); ?>, <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
          </td>
          <td>
            <?php
            $total = 0;
            ?>
            <?php $__currentLoopData = $value->spareparts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sparepart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $total += $sparepart->harga;
            ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            Rp. <?php echo e(number_format($total, 0,0)); ?>

          </td>
          <td><?php echo e($value->keterangan); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
$('#dataPerbaikan').DataTable({
  autoWidth: true,
  "lengthMenu": [
    [10, 25, 50, -1],
    [10, 25, 50, "All"]
  ]
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WORK\SI-Reminder-Management-Armada-PO-Haryanto\resources\views/mekanik/perbaikan.blade.php ENDPATH**/ ?>